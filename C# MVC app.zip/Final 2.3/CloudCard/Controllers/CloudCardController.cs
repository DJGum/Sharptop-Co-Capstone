﻿//Created by Micah Anderson

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CloudCard.Models;

namespace CloudCard.Controllers
{
    public class CloudCardController : Controller
    {
        
        public CloudCardService Service;
        
        //constructor class that creates instance of cloudcard service
        public CloudCardController()
        {
            Service = new CloudCardService("app.cloudcardtools.com", "pd9e0qvbs91gtnrna5sevb3l2j7des2c");
        }

        //Login page
        public IActionResult Login()
        {
            return View();
        }

        //String arguments passed into this method via the URL
        public IActionResult GetLink(string Email, string Name, string ID, string Campus)
        { 
            //Cannot connect to cloudcard redirct to error page
            if (!Service.IsCloudCardUp)
            {
                return RedirectToAction("Error_Main");
            }

            //*****To add custom fields follow formating and add here*****\\
            string json =
                $@"{{
                    ""email"":""{Email}"",
                    ""identifier"":""{ID}"",
                    ""customFields"":
                    {{
                        ""Name"":""{Name}"",
                        ""Campus"":""{Campus}""
                    }}
                    }}";

            //Create Person
            Person Person = Service.CreateOrUpdatePerson(json);
            
            //get login link
            string Link = Service.CreateLoginLink(ID);

            //get status of person
            string Status = (Person.Photo == null) ? "null" : Person.Photo.Status;



            //****Choose between an auto-redirect or get link and status page****\\

            //***OPTION 1: Redirect to cloudcard automatically***\\
            //return Redirect(Link);

            //***OPTION 2: Displays link and status***\\
            ViewData["Status"] = Status;
            ViewData["Name"] = Name;
            ViewData["Link"] = Link;

            return View();
        }

        //cloudcard down error page
        public IActionResult Error_Main()
        {
            return View();  
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}